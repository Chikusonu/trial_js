const express = require("express");
const router =new express.Router();
const Student=require("../models/students")
router.post("/student",async(req,res)=>{
    try{  const user= new Student(req.body)
      console.log(user);
      const createUser=await user.save();
      res.status(201).send(createUser);
    }
    catch(e){
      res.status(400).send(e);
    }
  
  })



router.get("/student",async(req,res)=>{
  try{
      const studentsData  = await Student.find();
      res.send(studentsData);
  }catch(e){
      res.send(e);
  }
})

router.get("/student/:id",async(req,res)=>{
  try{
    const _id=req.params.id;
    const studentData= await Student.findById(_id);
    console.log(studentData)
    if(!studentData){
      return res.status(404).send()
    }else{
      res.send(studentData);
    }
    
  }catch(e){
   res.send(studentData)
  }

})

router.patch("/student/:id",async(req,res)=>{
  try{
    const _id=req.params.id;
   const updateStudent = await  Student.findByIdAndUpdate(_id,req.body,{
    new:true

   });
   res.send(updateStudent);
  }catch(e){
res.status(404).send(updateStudent);
  }
})

router.delete("/student/:id",async(req,res)=>{
  try{
    //const _id=req.params.id;
   const deleteStudent = await  Student.findByIdAndDelete(req.params.id);
   if(!deleteStudent){
    req.status(404).send();
   }
   res.send(deleteStudent);
  }catch(e){
res.status(500).send(e);
  }
})


module.exports= router;